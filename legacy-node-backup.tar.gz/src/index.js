const { Client, Collection, GatewayIntentBits, MessageFlags } = require('discord.js');
const config = require('./config');
const profilCommand = require('./commands/profil');
const competencesCommand = require('./commands/competences');
const jjkCommand = require('./commands/jjk');

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

client.commands = new Collection();
client.commands.set(profilCommand.data.name, profilCommand);
client.commands.set(competencesCommand.data.name, competencesCommand);
client.commands.set(jjkCommand.data.name, jjkCommand);

client.once('clientReady', (readyClient) => {
  console.log(`Bot connecté : ${readyClient.user.tag}`);
});

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isAutocomplete()) {
      const command = client.commands.get(interaction.commandName);
      if (command?.autocomplete) await command.autocomplete(interaction);
      return;
    }

    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (command) await command.execute(interaction);
      return;
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('profil:')) {
      await profilCommand.handleInteraction(interaction);
      return;
    }

    if ((interaction.isButton() || interaction.isStringSelectMenu())
      && interaction.customId.startsWith('profil:')) {
      await profilCommand.handleInteraction(interaction);
      return;
    }

    if ((interaction.isButton() || interaction.isStringSelectMenu())
      && interaction.customId.startsWith('competences:')) {
      await competencesCommand.handleInteraction(interaction);
    }
  } catch (error) {
    console.error('Erreur pendant le traitement d’une interaction :', error);

    const response = {
      content: 'Une erreur est survenue. Vérifie les logs du bot pour plus de détails.',
      flags: MessageFlags.Ephemeral,
    };

    if (interaction.deferred || interaction.replied) {
      await interaction.followUp(response).catch(() => {});
    } else {
      await interaction.reply(response).catch(() => {});
    }
  }
});

client.login(config.token);
