const sharp = require('sharp');

const CARD_WIDTH = 1024;
const QUOTE_HEIGHT = 256;
const PROFILE_HEIGHT = 980;
const MAX_TEXT_LINES = 4;

function escapeXml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&apos;');
}

function wrapText(value, maxCharacters) {
  const words = String(value || '').trim().split(/\s+/).filter(Boolean);
  const lines = [];
  let current = '';

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (candidate.length <= maxCharacters || !current) {
      current = candidate;
    } else {
      lines.push(current);
      current = word;
    }
  }

  if (current) lines.push(current);
  return lines.length ? lines : ['Aucune citation renseignée.'];
}

function limitLines(lines) {
  if (lines.length <= MAX_TEXT_LINES) return lines;
  const limited = lines.slice(0, MAX_TEXT_LINES);
  const lastLine = limited[MAX_TEXT_LINES - 1];
  limited[MAX_TEXT_LINES - 1] = `${lastLine.slice(0, Math.max(1, lastLine.length - 1))}…`;
  return limited;
}

function createQuoteSvg(quote) {
  const lines = limitLines(wrapText(quote, 46));
  const fontSize = lines.length >= 4 ? 22 : lines.length >= 3 ? 25 : 29;
  const lineHeight = fontSize + 9;
  const firstLineY = 139 - ((lines.length - 1) * lineHeight) / 2;
  const textLines = lines.map((line, index) => `
    <text x="512" y="${firstLineY + index * lineHeight}"
      text-anchor="middle" fill="#f0ece2" font-size="${fontSize}"
      font-family="Georgia, Times New Roman, serif" font-weight="600">
      ${escapeXml(line)}
    </text>`).join('');

  return `<svg width="${CARD_WIDTH}" height="${QUOTE_HEIGHT}" viewBox="0 0 ${CARD_WIDTH} ${QUOTE_HEIGHT}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <filter id="text-shadow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur in="SourceAlpha" stdDeviation="2" result="blur" />
        <feOffset dy="2" result="offsetBlur" />
        <feComponentTransfer><feFuncA type="linear" slope="0.7" /></feComponentTransfer>
        <feMerge><feMergeNode /><feMergeNode in="SourceGraphic" /></feMerge>
      </filter>
    </defs>
    <rect x="185" y="48" width="654" height="160" rx="8" fill="#4b0d14" fill-opacity="0.58" stroke="#c9b458" stroke-width="2" />
    <text x="512" y="78" text-anchor="middle" fill="#c9b458" font-size="15"
      font-family="Georgia, Times New Roman, serif" font-weight="700" letter-spacing="4"
      filter="url(#text-shadow)">✦ CITATION ✦</text>
    <line x1="330" y1="91" x2="694" y2="91" stroke="#8a6b2f" stroke-width="1" />
    <g filter="url(#text-shadow)">${textLines}
    </g>
  </svg>`;
}

function createProfileLayoutSvg(profile, targetUser, hasImage) {
  const lines = [
    ['Nom', profile.name],
    ['Race', profile.race],
    ['Classe / grade', profile.characterClass],
    ['Camp', profile.camp],
  ];
  const infoLines = lines.map(([label, value], index) => {
    const y = 238 + index * 78;
    return `
      <text x="92" y="${y}" fill="#c9b458" font-size="18" font-family="Georgia, Times New Roman, serif" font-weight="700" letter-spacing="1">${escapeXml(label.toUpperCase())}</text>
      <text x="92" y="${y + 34}" fill="#f0ece2" font-size="28" font-family="Georgia, Times New Roman, serif" font-weight="600">${escapeXml(value)}</text>`;
  }).join('');

  const author = targetUser?.username ? `• ${targetUser.username}` : '';
  const imagePlaceholder = hasImage
    ? ''
    : `<text x="733" y="405" text-anchor="middle" fill="#c9b458" font-size="22" font-family="Georgia, Times New Roman, serif">Aucune image</text>`;

  return `<svg width="${CARD_WIDTH}" height="${PROFILE_HEIGHT}" viewBox="0 0 ${CARD_WIDTH} ${PROFILE_HEIGHT}" xmlns="http://www.w3.org/2000/svg">
    <rect width="${CARD_WIDTH}" height="${PROFILE_HEIGHT}" fill="#252a2e" />
    <rect x="26" y="26" width="972" height="928" rx="10" fill="none" stroke="#9a0a16" stroke-width="8" />
    <rect x="42" y="42" width="940" height="896" rx="6" fill="none" stroke="#8a6b2f" stroke-width="2" />

    <rect x="68" y="68" width="888" height="108" rx="6" fill="#4b0d14" stroke="#c9b458" stroke-width="2" />
    <text x="512" y="113" text-anchor="middle" fill="#c9b458" font-size="19" font-family="Georgia, Times New Roman, serif" font-weight="700" letter-spacing="5">✦ PROFIL RP ${escapeXml(author)} ✦</text>
    <text x="512" y="151" text-anchor="middle" fill="#f0ece2" font-size="30" font-family="Georgia, Times New Roman, serif" font-weight="700">${escapeXml(profile.name)}</text>

    <rect x="68" y="204" width="432" height="392" rx="6" fill="#4b0d14" fill-opacity="0.72" stroke="#8a6b2f" stroke-width="2" />
    ${infoLines}

    <rect x="510" y="204" width="446" height="410" rx="6" fill="#1d2024" stroke="#c9b458" stroke-width="3" />
    <rect x="526" y="220" width="414" height="378" rx="4" fill="none" stroke="#8a6b2f" stroke-width="2" />
    ${imagePlaceholder}

    <text x="512" y="622" text-anchor="middle" fill="#c9b458" font-size="16" font-family="Georgia, Times New Roman, serif" letter-spacing="4">✦ CITATION DU PERSONNAGE ✦</text>
  </svg>`;
}

async function fetchBuffer(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Téléchargement de l’image impossible (${response.status}).`);
  return Buffer.from(await response.arrayBuffer());
}

async function createProfileQuoteCard(quote, backgroundUrl) {
  if (!backgroundUrl) return null;

  try {
    const background = await fetchBuffer(backgroundUrl);
    return sharp(background)
      .resize(CARD_WIDTH, QUOTE_HEIGHT, { fit: 'cover' })
      .composite([{ input: Buffer.from(createQuoteSvg(quote)), blend: 'over' }])
      .png()
      .toBuffer();
  } catch (error) {
    console.error('Impossible de générer la carte de citation :', error.message);
    return null;
  }
}

async function createGlobalProfileCard(profile, targetUser, backgroundUrl) {
  try {
    const layers = [{
      input: Buffer.from(createProfileLayoutSvg(profile, targetUser, Boolean(profile.imageUrl))),
      blend: 'over',
    }];

    if (profile.imageUrl) {
      try {
        const characterImage = await fetchBuffer(profile.imageUrl);
        const resizedCharacter = await sharp(characterImage)
          .resize(402, 366, { fit: 'cover' })
          .png()
          .toBuffer();
        layers.push({ input: resizedCharacter, left: 532, top: 226, blend: 'over' });
      } catch (error) {
        console.error('Impossible de charger l’image du personnage :', error.message);
      }
    }

    if (backgroundUrl) {
      try {
        const quoteBackground = await fetchBuffer(backgroundUrl);
        const resizedQuoteBackground = await sharp(quoteBackground)
          .resize(CARD_WIDTH, QUOTE_HEIGHT, { fit: 'cover' })
          .png()
          .toBuffer();
        layers.push({ input: resizedQuoteBackground, left: 0, top: 674, blend: 'over' });
        layers.push({ input: Buffer.from(createQuoteSvg(profile.quote)), left: 0, top: 674, blend: 'over' });
      } catch (error) {
        console.error('Impossible de charger la bannière de citation :', error.message);
        layers.push({ input: Buffer.from(createQuoteSvg(profile.quote)), left: 0, top: 674, blend: 'over' });
      }
    } else {
      layers.push({ input: Buffer.from(createQuoteSvg(profile.quote)), left: 0, top: 674, blend: 'over' });
    }

    return sharp({
      create: {
        width: CARD_WIDTH,
        height: PROFILE_HEIGHT,
        channels: 4,
        background: '#252a2e',
      },
    }).composite(layers).png().toBuffer();
  } catch (error) {
    console.error('Impossible de générer la fiche globale :', error.message);
    return null;
  }
}

module.exports = {
  createGlobalProfileCard,
  createProfileQuoteCard,
};
