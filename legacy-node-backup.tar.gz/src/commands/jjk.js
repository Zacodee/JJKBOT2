const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const {
  BRAND_COLOR,
  buildEmbeds,
  contentLine,
  highlightLine,
  sectionTitle,
  separator,
} = require('../theme');

const data = new SlashCommandBuilder()
  .setName('jjk')
  .setDescription('Guide du bot et aide pour les nouveaux membres')
  .setDMPermission(false)
  .addSubcommand((subcommand) => subcommand
    .setName('help')
    .setDescription('Guide de démarrage et utilité des commandes'));

function createHelpEmbed() {
  const embed = new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setTitle(sectionTitle('⛩️', 'Guide du nouveau sorcier'))
    .setDescription([
      'Bienvenue dans le monde du jujutsu ! Ce guide t’explique pas à pas comment créer ton personnage et utiliser les commandes du bot.',
      separator(),
      highlightLine('🎭 Créer ton personnage'),
      contentLine('📛', 'Étape 1/2', '/profil creer — nom, race, classe, camp, citation'),
      contentLine('🧬', 'Étape 2/2', '/profil creer — traits et défauts (facultatifs)'),
      contentLine('🖼️', 'Image', '/profil image — PNG ou GIF de ton personnage'),
      separator(),
      highlightLine('📋 Consulter et modifier ta fiche'),
      contentLine('👤', 'Voir', '/profil voir — 3 pages navigables'),
      contentLine('✏️', 'Modifier', '/profil modifier'),
      contentLine('📊', 'Statistiques', 'Force, Résistance, Vitesse, Réserve d’EO, Sortie d’EO'),
      separator(),
      highlightLine('⚔️ Points de statistique'),
      contentLine('💠', 'Dépenser', '/profil attribuer-stat — investis tes points'),
      contentLine('🎁', 'Recevoir', 'le staff t’en attribue avec /profil donner-points'),
      separator(),
      highlightLine('🌳 Compétences'),
      contentLine('🔍', 'Consulter', '/competences voir — l’arbre par catégorie'),
      contentLine('🛒', 'Acheter', '/competences acheter — panier multi-compétences'),
      contentLine('⭐', 'XP', 'obtenue en RP, attribuée par le staff avec /competences xp'),
      separator(),
      highlightLine('🛡️ Commandes du staff'),
      contentLine('🎁', 'Points de stat', '/profil donner-points'),
      contentLine('⭐', 'XP', '/competences xp'),
      contentLine('🗑️', 'Réinitialiser', '/profil reset — profil, stats ou compétences'),
    ].join('\n'))
    .setFooter({ text: '✦ Bonne aventure, sorcier. Que ton énergie occulte te guide. ✦' });

  if (config.helpGifUrl) {
    embed.setImage(config.helpGifUrl);
  }
  return embed;
}

async function execute(interaction) {
  await interaction.reply({ embeds: buildEmbeds(createHelpEmbed()) });
}

module.exports = {
  data,
  execute,
};
