const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
  PermissionFlagsBits,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
} = require('discord.js');
const { getProfile, saveProfile } = require('../database/profiles');
const {
  SKILL_TREE,
  canUnlockSkill,
  getMissingPrerequisites,
  getSkill,
} = require('../data/skill-tree');
const {
  BRAND_COLOR,
  buildEmbeds,
  contentLine,
  highlightLine,
  sectionTitle,
  separator,
} = require('../theme');

const COMPETENCES_COLOR = BRAND_COLOR;
const PENDING_PURCHASES = new Map();
const PURCHASE_TIMEOUT = 15 * 60 * 1000;
const BRANCHES = [...new Set(SKILL_TREE.map((skill) => skill.branch))];

const data = new SlashCommandBuilder()
  .setName('competences')
  .setDescription('Consulter et faire progresser l’arbre de compétences')
  .setDMPermission(false)
  .addSubcommand((subcommand) => subcommand
    .setName('voir')
    .setDescription('Afficher les compétences par catégorie')
    .addUserOption((option) => option
      .setName('joueur')
      .setDescription('Le joueur dont tu veux voir les compétences')
      .setRequired(false)))
  .addSubcommand((subcommand) => subcommand
    .setName('acheter')
    .setDescription('Ouvrir le panier de compétences'))
  .addSubcommand((subcommand) => subcommand
    .setName('xp')
    .setDescription('Donner de l’XP à un joueur (staff uniquement)')
    .addUserOption((option) => option
      .setName('joueur')
      .setDescription('Le joueur qui recevra l’XP')
      .setRequired(true))
    .addIntegerOption((option) => option
      .setName('montant')
      .setDescription('Le nombre d’XP à donner')
      .setMinValue(1)
      .setMaxValue(100000)
      .setRequired(true)));

function interactionKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

function isStaff(interaction) {
  return interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)
    || interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers);
}

function getSkillsForBranch(branch) {
  return SKILL_TREE.filter((skill) => skill.branch === branch);
}

function getAvailableSkills(profile, branch = null) {
  return SKILL_TREE.filter((skill) => (!branch || skill.branch === branch)
    && canUnlockSkill(profile, skill));
}

function createSkillLine(profile, skill) {
  const unlocked = profile.unlockedSkills.includes(skill.id);
  const available = canUnlockSkill(profile, skill);
  const status = unlocked ? '✅' : available ? '🔓' : '🔒';
  let line = contentLine(status, skill.label, `${skill.cost} XP`);

  if (!unlocked && !available && skill.prerequisites.length) {
    const missing = getMissingPrerequisites(skill.id, profile.unlockedSkills)
      .map((prerequisite) => prerequisite.label)
      .join(', ');
    if (missing) line += `\n↳ ${missing}`;
  }

  return line;
}

function setEmbedAuthor(embed, targetUser) {
  if (targetUser) {
    embed.setAuthor({
      name: `Compétences de ${targetUser.username}`,
      iconURL: targetUser.displayAvatarURL(),
    });
  }
  return embed;
}

function createOverviewEmbed(profile, targetUser) {
  const branchLines = BRANCHES.map((branch) => {
    const branchSkills = getSkillsForBranch(branch);
    const unlocked = branchSkills.filter((skill) => profile.unlockedSkills.includes(skill.id)).length;
    const available = getAvailableSkills(profile, branch).length;
    return contentLine('📂', branch, `${unlocked}/${branchSkills.length} débloquées • ${available} disponibles`);
  });

  return setEmbedAuthor(new EmbedBuilder()
    .setColor(COMPETENCES_COLOR)
    .setTitle(sectionTitle('🌳', 'Compétences'))
    .setDescription([
      highlightLine(`XP disponible — **${profile.experience}**`),
      highlightLine(`Compétences débloquées — **${profile.unlockedSkills.length} / ${SKILL_TREE.length}**`),
      separator(),
      ...branchLines,
    ].join('\n'))
    .setFooter({ text: '✦ Choisis une catégorie dans le menu pour afficher ses paliers.' }), targetUser);
}

function createCategoryEmbed(profile, targetUser, branch) {
  const skills = getSkillsForBranch(branch);
  const lines = skills.map((skill) => {
    const unlocked = profile.unlockedSkills.includes(skill.id);
    const available = canUnlockSkill(profile, skill);
    const status = unlocked ? '✅' : available ? '🔓' : '🔒';
    let line = contentLine(status, skill.label, `${skill.cost} XP`);

    if (!unlocked && !available && skill.prerequisites.length) {
      const missing = getMissingPrerequisites(skill.id, profile.unlockedSkills)
        .map((prerequisite) => prerequisite.label)
        .join(', ');
      if (missing) line += `\n↳ ${missing}`;
    }

    return line;
  });

  return setEmbedAuthor(new EmbedBuilder()
    .setColor(COMPETENCES_COLOR)
    .setTitle(sectionTitle('🌳', branch))
    .setDescription([
      highlightLine(`XP disponible — **${profile.experience}**`),
      highlightLine(`Progression — **${skills.filter((skill) => profile.unlockedSkills.includes(skill.id)).length} / ${skills.length}**`),
      separator(),
      ...lines,
    ].join('\n'))
    .setFooter({ text: '✦ Prérequis contrôlés automatiquement par le bot.' }), targetUser);
}

function createCategoryMenu(guildId, targetUserId) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`competences:view:category:${guildId}:${targetUserId}`)
    .setPlaceholder('Choisir une catégorie')
    .addOptions(BRANCHES.map((branch) => ({
      label: branch,
      value: branch,
      description: `Voir les paliers de ${branch}`.slice(0, 100),
    })));

  return new ActionRowBuilder().addComponents(menu);
}

function createShopRoot(profile, guildId, userId, message = null, pendingSkillIds = []) {
  const pending = new Set(pendingSkillIds);
  const availableByBranch = BRANCHES.filter((branch) => getAvailableSkills(profile, branch)
    .some((skill) => !pending.has(skill.id)));
  const embed = new EmbedBuilder()
    .setColor(COMPETENCES_COLOR)
    .setTitle(sectionTitle('🛒', 'Panier de compétences'))
    .setDescription([
      message,
      highlightLine(`XP disponible — **${profile.experience}**`),
      availableByBranch.length
        ? contentLine('🗂️', 'Catégories', 'choisis-en une pour sélectionner des compétences')
        : 'Aucune compétence supplémentaire n’est actuellement achetable. Vérifie tes prérequis ou demande de l’XP au staff.',
      'La confirmation recalculera le coût et les prérequis avant l’achat.',
    ].filter(Boolean).join('\n'));

  if (pendingSkillIds.length) {
    const basket = createBasket(profile, pendingSkillIds);
    embed.setDescription([
      embed.data.description,
      separator(),
      highlightLine(`Panier en cours — ${basket.total} XP`),
      ...basket.skills.map((skill) => contentLine('📦', skill.label, `${skill.cost} XP`)),
    ].join('\n'));
  }

  if (!availableByBranch.length) {
    return {
      embeds: buildEmbeds(embed),
      components: pendingSkillIds.length
        ? [createBasketComponents(guildId, userId, false)]
        : [],
    };
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId(`competences:shop:category:${guildId}:${userId}`)
    .setPlaceholder('Choisir une catégorie')
    .addOptions(availableByBranch.map((branch) => ({
      label: branch,
      value: branch,
      description: `${getAvailableSkills(profile, branch).length} compétence(s) disponible(s)`.slice(0, 100),
    })));

  return {
    embeds: buildEmbeds(embed),
    components: [new ActionRowBuilder().addComponents(menu)],
  };
}

function createSkillShop(profile, guildId, userId, branch, excludedSkillIds = []) {
  const excluded = new Set(excludedSkillIds);
  const available = getAvailableSkills(profile, branch)
    .filter((skill) => !excluded.has(skill.id));
  const embed = new EmbedBuilder()
    .setColor(COMPETENCES_COLOR)
    .setTitle(sectionTitle('🛒', branch))
    .setDescription('Sélectionne une ou plusieurs compétences, puis confirme le panier.');

  if (!available.length) {
    return {
      embeds: buildEmbeds(embed.setDescription('Aucune compétence de cette catégorie n’est disponible actuellement.')),
      components: [],
    };
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId(`competences:shop:skills:${guildId}:${userId}:${encodeURIComponent(branch)}`)
    .setPlaceholder('Sélectionner des compétences')
    .setMinValues(1)
    .setMaxValues(available.length)
    .addOptions(available.map((skill) => ({
      label: skill.label,
      value: skill.id,
      description: `${skill.cost} XP`.slice(0, 100),
    })));

  return {
    embeds: buildEmbeds(embed.setDescription([
      embed.data.description,
      separator(),
      ...available.map((skill) => contentLine('🔓', skill.label, `${skill.cost} XP`)),
    ].join('\n'))),
    components: [new ActionRowBuilder().addComponents(menu)],
  };
}

function createBasket(profile, skillIds) {
  const skills = skillIds.map((skillId) => getSkill(skillId)).filter(Boolean);
  const total = skills.reduce((sum, skill) => sum + skill.cost, 0);
  const embed = new EmbedBuilder()
    .setColor(COMPETENCES_COLOR)
    .setTitle(sectionTitle('🛒', 'Confirmation du panier'))
    .setDescription([
      highlightLine(`XP disponible — **${profile.experience}**`),
      highlightLine(`Coût total — **${total} XP**`),
      profile.experience >= total ? '✅ Le panier est finançable.' : '❌ Tu n’as pas assez d’XP.',
      separator(),
      ...skills.map((skill) => contentLine('📦', skill.label, `${skill.cost} XP`)),
    ].join('\n'));

  return { embed, total, skills };
}

function createBasketComponents(guildId, userId, canAddCategory) {
  const buttons = [
    new ButtonBuilder()
      .setCustomId(`competences:shop:confirm:${guildId}:${userId}`)
      .setLabel('Confirmer l’achat')
      .setStyle(ButtonStyle.Danger),
  ];

  if (canAddCategory) {
    buttons.push(new ButtonBuilder()
      .setCustomId(`competences:shop:add:${guildId}:${userId}`)
      .setLabel('Ajouter une catégorie')
      .setStyle(ButtonStyle.Danger));
  }

  buttons.push(new ButtonBuilder()
    .setCustomId(`competences:shop:cancel:${guildId}:${userId}`)
    .setLabel('Annuler')
    .setStyle(ButtonStyle.Secondary));

  return new ActionRowBuilder().addComponents(buttons);
}

function createContinueComponents(guildId, userId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`competences:shop:continue:${guildId}:${userId}`)
      .setLabel('Continuer les achats')
      .setStyle(ButtonStyle.Danger),
  );
}

async function replyMissingProfile(interaction, targetUser) {
  const message = targetUser.id === interaction.user.id
    ? 'Tu n’as pas encore de profil. Lance `/profil creer`.'
    : `${targetUser.username} n’a pas encore créé de profil.`;
  await interaction.reply({ content: message, flags: MessageFlags.Ephemeral });
}

async function execute(interaction) {
  if (!interaction.guildId) {
    await interaction.reply({ content: 'Les compétences sont disponibles uniquement sur un serveur.', flags: MessageFlags.Ephemeral });
    return;
  }

  const subcommand = interaction.options.getSubcommand();

  if (subcommand === 'voir') {
    const targetUser = interaction.options.getUser('joueur') || interaction.user;
    const profile = await getProfile(interaction.guildId, targetUser.id);
    if (!profile) {
      await replyMissingProfile(interaction, targetUser);
      return;
    }

    await interaction.reply({
      embeds: buildEmbeds(createOverviewEmbed(profile, targetUser)),
      components: [createCategoryMenu(interaction.guildId, targetUser.id)],
    });
    return;
  }

  if (subcommand === 'acheter') {
    const profile = await getProfile(interaction.guildId, interaction.user.id);
    if (!profile) {
      await replyMissingProfile(interaction, interaction.user);
      return;
    }

    await interaction.reply({
      ...createShopRoot(profile, interaction.guildId, interaction.user.id),
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (subcommand === 'xp') {
    if (!isStaff(interaction)) {
      await interaction.reply({
        content: 'Cette commande est réservée au staff : Administrateur ou Modérer les membres.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const targetUser = interaction.options.getUser('joueur');
    const amount = interaction.options.getInteger('montant');
    const profile = await getProfile(interaction.guildId, targetUser.id);
    if (!profile) {
      await interaction.reply({
        content: `${targetUser.username} doit d’abord créer son profil avec /profil creer.`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    profile.experience += amount;
    profile.updatedAt = new Date().toISOString();
    await saveProfile(interaction.guildId, targetUser.id, profile);
    await interaction.reply({
      content: `✅ **${amount} XP** ajouté à **${targetUser.username}**. Total : **${profile.experience} XP**.`,
      flags: MessageFlags.Ephemeral,
    });
  }
}

function rememberPurchase(guildId, userId, skillIds) {
  const key = interactionKey(guildId, userId);
  const previous = PENDING_PURCHASES.get(key);
  if (previous?.timeout) clearTimeout(previous.timeout);
  const timeout = setTimeout(() => PENDING_PURCHASES.delete(key), PURCHASE_TIMEOUT);
  timeout.unref?.();
  PENDING_PURCHASES.set(key, { skillIds, timeout });
}

function isOwner(interaction, userId) {
  if (interaction.user.id === userId) return true;
  interaction.reply({
    content: 'Ce menu appartient à un autre joueur.',
    flags: MessageFlags.Ephemeral,
  }).catch(() => {});
  return false;
}

async function handleViewCategory(interaction) {
  const [, , , guildId, targetUserId] = interaction.customId.split(':');
  if (guildId !== interaction.guildId) return;

  const branch = interaction.values[0];
  if (!BRANCHES.includes(branch)) return;
  const profile = await getProfile(guildId, targetUserId);
  if (!profile) {
    await interaction.update({ content: 'Ce profil n’existe plus.', embeds: [], components: [] });
    return;
  }

  const targetUser = await interaction.client.users.fetch(targetUserId);
  await interaction.update({
    embeds: buildEmbeds(createCategoryEmbed(profile, targetUser, branch)),
    components: [createCategoryMenu(guildId, targetUserId)],
  });
}

async function handleShopCategory(interaction) {
  const [, , , guildId, userId] = interaction.customId.split(':');
  if (guildId !== interaction.guildId || !isOwner(interaction, userId)) return;

  const branch = interaction.values[0];
  if (!BRANCHES.includes(branch)) return;
  const profile = await getProfile(guildId, userId);
  if (!profile) {
    await interaction.update({ content: 'Ton profil n’existe plus.', embeds: [], components: [] });
    return;
  }

  const pending = PENDING_PURCHASES.get(interactionKey(guildId, userId));
  await interaction.update(createShopSkillSelectorResponse(
    profile,
    guildId,
    userId,
    branch,
    pending?.skillIds || [],
  ));
}

function createShopSkillSelectorResponse(profile, guildId, userId, branch, pendingSkillIds = []) {
  return createSkillShop(profile, guildId, userId, branch, pendingSkillIds);
}

async function handleShopSkills(interaction) {
  const [, , , guildId, userId, encodedBranch] = interaction.customId.split(':');
  if (guildId !== interaction.guildId || !isOwner(interaction, userId)) return;

  const branch = decodeURIComponent(encodedBranch);
  const profile = await getProfile(guildId, userId);
  if (!profile) {
    await interaction.update({ content: 'Ton profil n’existe plus.', embeds: [], components: [] });
    return;
  }

  const selectedSkillIds = [...new Set(interaction.values)];
  const selectedSkills = selectedSkillIds
    .map((skillId) => getSkill(skillId))
    .filter((skill) => skill && skill.branch === branch && canUnlockSkill(profile, skill));

  if (selectedSkills.length !== selectedSkillIds.length) {
    await interaction.update({
      ...createShopRoot(profile, guildId, userId, 'Certaines compétences sélectionnées ne sont plus disponibles.'),
    });
    return;
  }

  const existingPurchase = PENDING_PURCHASES.get(interactionKey(guildId, userId));
  const skillIds = [...new Set([
    ...(existingPurchase?.skillIds || []),
    ...selectedSkills.map((skill) => skill.id),
  ])];
  rememberPurchase(guildId, userId, skillIds);
  const basket = createBasket(profile, skillIds);
  const hasMoreSkills = getAvailableSkills(profile)
    .some((skill) => !skillIds.includes(skill.id));
  await interaction.update({
    embeds: buildEmbeds(basket.embed),
    components: [createBasketComponents(guildId, userId, hasMoreSkills)],
  });
}

async function handleShopAdd(interaction) {
  const [, , , guildId, userId] = interaction.customId.split(':');
  if (guildId !== interaction.guildId || !isOwner(interaction, userId)) return;

  const profile = await getProfile(guildId, userId);
  const pending = PENDING_PURCHASES.get(interactionKey(guildId, userId));
  if (!profile || !pending) {
    await interaction.update({ content: 'Ce panier a expiré. Relance `/competences acheter`.', embeds: [], components: [] });
    return;
  }

  await interaction.update(createShopRoot(profile, guildId, userId, null, pending.skillIds));
}

async function handleShopConfirm(interaction) {
  const [, , , guildId, userId] = interaction.customId.split(':');
  if (guildId !== interaction.guildId || !isOwner(interaction, userId)) return;

  const key = interactionKey(guildId, userId);
  const pending = PENDING_PURCHASES.get(key);
  const profile = await getProfile(guildId, userId);
  if (!pending || !profile) {
    await interaction.update({ content: 'Ce panier a expiré. Relance `/competences acheter`.', embeds: [], components: [] });
    return;
  }

  const skills = pending.skillIds.map((skillId) => getSkill(skillId));
  const stillAvailable = skills.every((skill) => skill && canUnlockSkill(profile, skill));
  const total = skills.reduce((sum, skill) => sum + skill.cost, 0);
  if (!stillAvailable || profile.experience < total) {
    clearTimeout(pending.timeout);
    PENDING_PURCHASES.delete(key);
    await interaction.update({
      ...createShopRoot(profile, guildId, userId, 'Le panier n’est plus valide ou ton XP est insuffisante.'),
    });
    return;
  }

  for (const skill of skills) profile.unlockedSkills.push(skill.id);
  profile.experience -= total;
  profile.updatedAt = new Date().toISOString();
  await saveProfile(guildId, userId, profile);
  clearTimeout(pending.timeout);
  PENDING_PURCHASES.delete(key);

  await interaction.update({
    content: `✅ ${skills.length} compétence(s) débloquée(s) pour **${total} XP**. Il te reste **${profile.experience} XP**.`,
    embeds: buildEmbeds(createOverviewEmbed(profile, interaction.user)),
    components: [createContinueComponents(guildId, userId)],
  });
}

async function handleShopCancel(interaction) {
  const [, , , guildId, userId] = interaction.customId.split(':');
  if (guildId !== interaction.guildId || !isOwner(interaction, userId)) return;

  const key = interactionKey(guildId, userId);
  const pending = PENDING_PURCHASES.get(key);
  if (pending?.timeout) clearTimeout(pending.timeout);
  PENDING_PURCHASES.delete(key);
  const profile = await getProfile(guildId, userId);
  if (!profile) {
    await interaction.update({ content: 'Ton profil n’existe plus.', embeds: [], components: [] });
    return;
  }

  await interaction.update(createShopRoot(profile, guildId, userId));
}

async function handleShopContinue(interaction) {
  const [, , , guildId, userId] = interaction.customId.split(':');
  if (guildId !== interaction.guildId || !isOwner(interaction, userId)) return;
  const profile = await getProfile(guildId, userId);
  if (!profile) {
    await interaction.update({ content: 'Ton profil n’existe plus.', embeds: [], components: [] });
    return;
  }

  await interaction.update(createShopRoot(profile, guildId, userId));
}

async function handleInteraction(interaction) {
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId.startsWith('competences:view:category:')) {
      await handleViewCategory(interaction);
    } else if (interaction.customId.startsWith('competences:shop:category:')) {
      await handleShopCategory(interaction);
    } else if (interaction.customId.startsWith('competences:shop:skills:')) {
      await handleShopSkills(interaction);
    }
    return;
  }

  if (!interaction.isButton() || !interaction.customId.startsWith('competences:shop:')) return;
  if (interaction.customId.includes(':confirm:')) {
    await handleShopConfirm(interaction);
  } else if (interaction.customId.includes(':cancel:')) {
    await handleShopCancel(interaction);
  } else if (interaction.customId.includes(':add:')) {
    await handleShopAdd(interaction);
  } else if (interaction.customId.includes(':continue:')) {
    await handleShopContinue(interaction);
  }
}

module.exports = {
  data,
  execute,
  handleInteraction,
};
