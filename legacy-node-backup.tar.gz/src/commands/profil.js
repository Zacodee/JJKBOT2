const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
  ModalBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { deleteProfile, getProfile, saveProfile } = require('../database/profiles');
const config = require('../config');
const { DEFAULT_STATS, STAT_DEFINITIONS, getStatDefinition } = require('../data/stats');
const {
  createGlobalProfileCard,
  createProfileQuoteCard,
} = require('../graphics/profile-card');
const {
  BRAND_COLOR,
  buildEmbeds,
  contentLine,
  highlightLine,
  sectionTitle,
  separator,
} = require('../theme');

const PROFILE_COLOR = BRAND_COLOR;
const PENDING_CREATIONS = new Map();
const PENDING_RESETS = new Map();
const PENDING_TIMEOUT = 15 * 60 * 1000;

const RESET_LABELS = {
  profil: 'le profil complet (fiche, stats, compétences et image)',
  stats: 'les statistiques et les points disponibles',
  competences: 'les compétences débloquées et l’XP',
};

const data = new SlashCommandBuilder()
  .setName('profil')
  .setDescription('Consulter ou créer une fiche de personnage')
  .setDMPermission(false)
  .addSubcommand((subcommand) => subcommand
    .setName('voir')
    .setDescription('Afficher une fiche de personnage')
    .addUserOption((option) => option
      .setName('joueur')
      .setDescription('Le joueur dont tu veux voir le profil')
      .setRequired(false)))
  .addSubcommand((subcommand) => subcommand
    .setName('creer')
    .setDescription('Créer ta fiche avec l’aide du bot'))
  .addSubcommand((subcommand) => subcommand
    .setName('modifier')
    .setDescription('Modifier ta fiche de personnage'))
  .addSubcommand((subcommand) => subcommand
    .setName('image')
    .setDescription('Ajouter ou remplacer l’image de ton personnage')
    .addAttachmentOption((option) => option
      .setName('fichier')
      .setDescription('Une image PNG ou un GIF de ton personnage')
      .setRequired(true)))
  .addSubcommand((subcommand) => subcommand
    .setName('donner-points')
    .setDescription('Donner des points de statistique à un joueur (staff uniquement)')
    .addUserOption((option) => option
      .setName('joueur')
      .setDescription('Le joueur qui recevra les points')
      .setRequired(true))
    .addIntegerOption((option) => option
      .setName('montant')
      .setDescription('Le nombre de points à donner')
      .setMinValue(1)
      .setMaxValue(100000)
      .setRequired(true)))
  .addSubcommand((subcommand) => subcommand
    .setName('attribuer-stat')
    .setDescription('Dépenser tes points dans une statistique')
    .addStringOption((option) => option
      .setName('statistique')
      .setDescription('La statistique à améliorer')
      .setChoices(...STAT_DEFINITIONS.map((stat) => ({ name: stat.label, value: stat.id })))
      .setRequired(true))
    .addIntegerOption((option) => option
      .setName('montant')
      .setDescription('Le nombre de points à investir')
      .setMinValue(1)
      .setMaxValue(100000)
      .setRequired(true)))
  .addSubcommand((subcommand) => subcommand
    .setName('reset')
    .setDescription('Réinitialiser les données d’un joueur (staff uniquement)')
    .addUserOption((option) => option
      .setName('joueur')
      .setDescription('Le joueur concerné')
      .setRequired(true))
    .addStringOption((option) => option
      .setName('type')
      .setDescription('Que veux-tu réinitialiser ?')
      .setChoices(
        { name: 'Profil complet (supprime tout)', value: 'profil' },
        { name: 'Statistiques', value: 'stats' },
        { name: 'Compétences (et XP)', value: 'competences' },
      )
      .setRequired(true)));

function createQuoteCardEmbed(quoteCardAttachment) {
  return new EmbedBuilder()
    .setColor(PROFILE_COLOR)
    .setImage(`attachment://${quoteCardAttachment.name}`);
}

function buildProfileEmbeds(contentEmbed) {
  return [contentEmbed];
}

async function buildProfileResponse(profile, targetUser, page = 'global') {
  if (page === 'global') {
    const globalCard = await createGlobalProfileCard(
      profile,
      targetUser,
      config.profileBannerUrl,
    );
    const globalCardAttachment = globalCard
      ? { attachment: globalCard, name: 'profile-global.png' }
      : null;
    const response = {
      embeds: globalCardAttachment
        ? [new EmbedBuilder().setColor(PROFILE_COLOR).setImage(`attachment://${globalCardAttachment.name}`)]
        : buildProfileEmbeds(createProfileEmbed(profile, targetUser, page)),
    };

    if (globalCardAttachment) response.files = [globalCardAttachment];
    return response;
  }

  const quoteCard = await createProfileQuoteCard(profile.quote, config.profileBannerUrl);
  const quoteCardAttachment = quoteCard ? { attachment: quoteCard, name: 'profile-quote.png' } : null;
  const response = {
    embeds: quoteCardAttachment
      ? [createQuoteCardEmbed(quoteCardAttachment), createProfileEmbed(profile, targetUser, page)]
      : buildProfileEmbeds(createProfileEmbed(profile, targetUser, page)),
  };

  if (quoteCardAttachment) response.files = [quoteCardAttachment];
  return response;
}

function profileKey(interaction) {
  return `${interaction.guildId}:${interaction.user.id}`;
}

function textValue(interaction, inputId) {
  return interaction.fields.getTextInputValue(inputId).trim();
}

function parseEntries(value) {
  return value
    .split(/[\n,]/)
    .map((entry) => entry.trim())
    .filter(Boolean)
    .slice(0, 10)
    .map((entry) => entry.slice(0, 60));
}

function createInput(customId, label, options = {}) {
  const input = new TextInputBuilder()
    .setCustomId(customId)
    .setLabel(label)
    .setStyle(options.style || TextInputStyle.Short)
    .setRequired(options.required ?? true)
    .setMaxLength(options.maxLength || 100);

  if (options.placeholder) input.setPlaceholder(options.placeholder);
  if (options.value) input.setValue(options.value.slice(0, options.maxLength || 100));
  return input;
}

function createGlobalModal(mode, profile = {}) {
  const modal = new ModalBuilder()
    .setCustomId(`profil:${mode}:global`)
    .setTitle(mode === 'create' ? 'Créer ton profil — 1/2' : 'Modifier ton profil — 1/2');

  const fields = [
    createInput('characterName', 'Nom du personnage', {
      placeholder: 'Ex. Kiraiya',
      value: profile.name,
      maxLength: 60,
    }),
    createInput('race', 'Race', {
      placeholder: 'Ex. Humain, fléau...',
      value: profile.race,
      maxLength: 40,
    }),
    createInput('characterClass', 'Classe / grade', {
      placeholder: 'Ex. Spécial, étudiant...',
      value: profile.characterClass,
      maxLength: 60,
    }),
    createInput('camp', 'Camp / alignement', {
      placeholder: 'Ex. Neutre, école de Tokyo...',
      value: profile.camp,
      maxLength: 60,
    }),
    createInput('quote', 'Citation personnelle', {
      placeholder: 'Une phrase qui représente ton personnage',
      value: profile.quote,
      style: TextInputStyle.Paragraph,
      maxLength: 300,
    }),
  ];

  for (const field of fields) {
    modal.addComponents(new ActionRowBuilder().addComponents(field));
  }
  return modal;
}

function createTraitsModal(mode, profile = {}) {
  const modal = new ModalBuilder()
    .setCustomId(`profil:${mode}:traits`)
    .setTitle(mode === 'create' ? 'Créer ton profil — 2/2' : 'Modifier ton profil — 2/2');

  const traits = Array.isArray(profile.traits) ? profile.traits.join('\n') : '';
  const flaws = Array.isArray(profile.flaws) ? profile.flaws.join('\n') : '';

  modal.addComponents(
    new ActionRowBuilder().addComponents(createInput('traits', 'Traits (facultatif)', {
      placeholder: 'Une entrée par ligne, ou laisse vide',
      value: traits,
      style: TextInputStyle.Paragraph,
      required: false,
      maxLength: 500,
    })),
    new ActionRowBuilder().addComponents(createInput('flaws', 'Défauts (facultatif)', {
      placeholder: 'Une entrée par ligne, ou laisse vide',
      value: flaws,
      style: TextInputStyle.Paragraph,
      required: false,
      maxLength: 500,
    })),
  );
  return modal;
}

function rememberReset(interaction, pending) {
  const key = profileKey(interaction);
  const previous = PENDING_RESETS.get(key);
  if (previous?.timeout) clearTimeout(previous.timeout);

  const timeout = setTimeout(() => PENDING_RESETS.delete(key), PENDING_TIMEOUT);
  timeout.unref?.();
  PENDING_RESETS.set(key, { ...pending, timeout });
}

function rememberPending(interaction, pending) {
  const key = profileKey(interaction);
  const previous = PENDING_CREATIONS.get(key);
  if (previous?.timeout) clearTimeout(previous.timeout);

  const timeout = setTimeout(() => PENDING_CREATIONS.delete(key), PENDING_TIMEOUT);
  timeout.unref?.();
  PENDING_CREATIONS.set(key, { ...pending, timeout });
}

function truncate(value, maxLength) {
  if (!value) return '';
  return value.length > maxLength ? `${value.slice(0, maxLength - 1)}…` : value;
}

function listEntries(entries) {
  return entries.length ? entries.map((entry) => `• ${entry}`).join('\n') : '*Aucun renseignement pour le moment.*';
}

function createNavigation(targetUserId, guildId, currentPage) {
  const pages = [
    ['global', '📜 Global'],
    ['stats', '📊 Statistiques'],
    ['traits', '🧬 Traits & défauts'],
  ];

  return new ActionRowBuilder().addComponents(
    pages.map(([page, label]) => new ButtonBuilder()
      .setCustomId(`profil:page:${page}:${guildId}:${targetUserId}`)
      .setLabel(label)
      .setStyle(page === currentPage ? ButtonStyle.Danger : ButtonStyle.Secondary)
      .setDisabled(page === currentPage)),
  );
}

function createProfileEmbed(profile, targetUser, page = 'global') {
  const pageNumber = page === 'global' ? '1' : page === 'stats' ? '2' : '3';
  const embed = new EmbedBuilder()
    .setColor(PROFILE_COLOR)
    .setFooter({ text: `✦ Page ${pageNumber} / 3 • Fiche RP • Noblesse Jujogo` })
    .setTimestamp(new Date(profile.updatedAt || profile.createdAt));


  if (targetUser) {
    embed.setAuthor({
      name: targetUser.username,
      iconURL: targetUser.displayAvatarURL(),
    });
  }

  if (page === 'global') {
    embed.setTitle(sectionTitle('📛', 'Profil'))
      .setDescription([
        contentLine('👤', 'Nom', profile.name),
        contentLine('🧬', 'Race', profile.race),
        contentLine('🎓', 'Classe / grade', profile.characterClass),
        contentLine('⚖️', 'Camp', profile.camp),
        separator(),
        `╭─ ✦ Citation\n╰─ ❝ ${truncate(profile.quote, 500)} ❞`,
      ].join('\n\n'));

    if (profile.imageUrl) {
      embed.setImage(profile.imageUrl);
    } else {
      embed.addFields({
        name: '🖼️  Image du personnage',
        value: 'Aucune image ajoutée. Utilise `/profil image` avec un PNG ou un GIF.',
      });
    }
  }

  if (page === 'stats') {
    embed.setTitle(sectionTitle('⚔️', 'Statistiques'))
      .setDescription([
        contentLine('👤', 'Personnage', profile.name),
        highlightLine(`Points à attribuer — **${profile.statPoints}**`),
        separator(),
        ...STAT_DEFINITIONS.map((stat) => contentLine(
          stat.icon,
          stat.label,
          `${profile.stats[stat.id]} point(s)`,
        )),
      ].join('\n\n'));
  }

  if (page === 'traits') {
    embed.setTitle(sectionTitle('🧬', 'Traits et défauts'))
      .setDescription([
        contentLine('👤', 'Personnage', profile.name),
        separator(),
        ...(profile.traits.length
          ? profile.traits.map((trait) => contentLine('✅', 'Trait', trait))
          : [contentLine('✅', 'Traits', 'Aucun renseignement')]),
        separator(),
        ...(profile.flaws.length
          ? profile.flaws.map((flaw) => contentLine('⚠️', 'Défaut', flaw))
          : [contentLine('⚠️', 'Défauts', 'Aucun renseignement')]),
      ].join('\n\n'));
  }

  return embed;
}

async function sendProfile(interaction, targetUser, page = 'global', options = {}) {
  const profile = await getProfile(interaction.guildId, targetUser.id);
  if (!profile) {
    const message = targetUser.id === interaction.user.id
      ? 'Tu n’as pas encore de profil. Lance `/profil creer` pour être guidé par le bot.'
      : `${targetUser.username} n’a pas encore créé de profil.`;
    await interaction.reply({ content: message, flags: MessageFlags.Ephemeral });
    return;
  }

  if (!interaction.deferred && !interaction.replied) {
    await interaction.deferReply(options.ephemeral ? { flags: MessageFlags.Ephemeral } : {});
  }

  const response = {
    ...(await buildProfileResponse(profile, targetUser, page)),
    components: [createNavigation(targetUser.id, interaction.guildId, page)],
  };

  if (options.content) response.content = options.content;
  await interaction.editReply(response);
}

function isStaff(interaction) {
  return interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)
    || interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers);
}

async function execute(interaction) {
  if (!interaction.guildId) {
    await interaction.reply({ content: 'Les profils sont disponibles uniquement sur un serveur.', flags: MessageFlags.Ephemeral });
    return;
  }

  const subcommand = interaction.options.getSubcommand();

  if (subcommand === 'voir') {
    const targetUser = interaction.options.getUser('joueur') || interaction.user;
    await sendProfile(interaction, targetUser);
    return;
  }

  if (subcommand === 'donner-points') {
    if (!isStaff(interaction)) {
      await interaction.reply({
        content: 'Cette commande est réservée au staff : Administrateur ou Modérer les membres.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const targetUser = interaction.options.getUser('joueur');
    const amount = interaction.options.getInteger('montant');
    const profile = await getProfile(interaction.guildId, targetUser.id);
    if (!profile) {
      await interaction.reply({
        content: `${targetUser.username} doit d’abord créer son profil avec /profil creer.`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    profile.statPoints += amount;
    profile.updatedAt = new Date().toISOString();
    await saveProfile(interaction.guildId, targetUser.id, profile);
    await interaction.reply({
      content: `✅ **${amount} point(s)** de statistique ajouté(s) à **${targetUser.username}**. Total disponible : **${profile.statPoints}**.`,
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (subcommand === 'attribuer-stat') {
    const profile = await getProfile(interaction.guildId, interaction.user.id);
    if (!profile) {
      await interaction.reply({
        content: 'Crée d’abord ton profil avec `/profil creer`.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const statId = interaction.options.getString('statistique');
    const amount = interaction.options.getInteger('montant');
    const stat = getStatDefinition(statId);
    if (!stat) {
      await interaction.reply({
        content: 'Cette statistique n’existe pas.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (profile.statPoints < amount) {
      await interaction.reply({
        content: `Tu n’as que **${profile.statPoints} point(s)** disponible(s).`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    profile.statPoints -= amount;
    profile.stats[stat.id] += amount;
    profile.updatedAt = new Date().toISOString();
    await saveProfile(interaction.guildId, interaction.user.id, profile);
    await interaction.reply({
      content: `✅ **${amount} point(s)** ajouté(s) en **${stat.label}**. Il te reste **${profile.statPoints} point(s)**.`,
      ...(await buildProfileResponse(profile, interaction.user, 'stats')),
      components: [createNavigation(interaction.user.id, interaction.guildId, 'stats')],
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (subcommand === 'reset') {
    if (!isStaff(interaction)) {
      await interaction.reply({
        content: 'Cette commande est réservée au staff : Administrateur ou Modérer les membres.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const targetUser = interaction.options.getUser('joueur');
    const resetType = interaction.options.getString('type');
    const profile = await getProfile(interaction.guildId, targetUser.id);
    if (!profile) {
      await interaction.reply({
        content: `${targetUser.username} n’a pas encore de profil à réinitialiser.`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    rememberReset(interaction, { targetUserId: targetUser.id, type: resetType });

    const confirmButton = new ButtonBuilder()
      .setCustomId('profil:reset:confirm')
      .setLabel('Oui, réinitialiser')
      .setStyle(ButtonStyle.Danger);
    const cancelButton = new ButtonBuilder()
      .setCustomId('profil:reset:cancel')
      .setLabel('Annuler')
      .setStyle(ButtonStyle.Secondary);

    await interaction.reply({
      content: `⚠️ Tu t’apprêtes à réinitialiser **${RESET_LABELS[resetType]}** de **${targetUser.username}**. Cette action est irréversible. Confirme pour continuer.`,
      components: [new ActionRowBuilder().addComponents(confirmButton, cancelButton)],
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (subcommand === 'creer' || subcommand === 'modifier') {
    const existingProfile = await getProfile(interaction.guildId, interaction.user.id);

    if (subcommand === 'creer' && existingProfile) {
      await interaction.reply({
        content: 'Tu as déjà un profil. Utilise `/profil modifier` pour le mettre à jour.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    if (subcommand === 'modifier' && !existingProfile) {
      await interaction.reply({
        content: 'Tu n’as pas encore de profil. Utilise `/profil creer` pour le créer.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const mode = subcommand === 'creer' ? 'create' : 'edit';
    await interaction.showModal(createGlobalModal(mode, existingProfile || {}));
    return;
  }

  if (subcommand === 'image') {
    const profile = await getProfile(interaction.guildId, interaction.user.id);
    if (!profile) {
      await interaction.reply({
        content: 'Crée d’abord ton profil avec `/profil creer`, puis ajoute ton image.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const attachment = interaction.options.getAttachment('fichier');
    const fileName = attachment.name.toLowerCase();
    const isPngOrGif = ['image/png', 'image/gif'].includes(attachment.contentType)
      || fileName.endsWith('.png')
      || fileName.endsWith('.gif');

    if (!isPngOrGif) {
      await interaction.reply({
        content: 'Le fichier doit être une image PNG ou un GIF.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    profile.imageUrl = attachment.url;
    profile.imageName = attachment.name;
    profile.imageType = fileName.endsWith('.gif') ? 'gif' : 'png';
    profile.updatedAt = new Date().toISOString();
    await saveProfile(interaction.guildId, interaction.user.id, profile);

    await sendProfile(interaction, interaction.user, 'global', {
      ephemeral: true,
      content: '✅ Image enregistrée sur ton profil.',
    });
  }
}

async function handleGlobalModal(interaction, mode) {
  const existingProfile = mode === 'edit'
    ? await getProfile(interaction.guildId, interaction.user.id)
    : null;

  rememberPending(interaction, {
    mode,
    existingProfile,
    global: {
      name: textValue(interaction, 'characterName'),
      race: textValue(interaction, 'race'),
      characterClass: textValue(interaction, 'characterClass'),
      camp: textValue(interaction, 'camp'),
      quote: textValue(interaction, 'quote'),
    },
  });

  const continueButton = new ButtonBuilder()
    .setCustomId(`profil:continue:traits:${mode}`)
    .setLabel('Continuer vers les traits et défauts')
    .setStyle(ButtonStyle.Danger);

  await interaction.reply({
    content: '✅ Étape 1/2 enregistrée. Clique sur le bouton pour passer à la seconde étape.',
    components: [new ActionRowBuilder().addComponents(continueButton)],
    flags: MessageFlags.Ephemeral,
  });
}

async function handleTraitsModal(interaction, mode) {
  const pending = PENDING_CREATIONS.get(profileKey(interaction));
  if (!pending || pending.mode !== mode) {
    await interaction.reply({
      content: 'Cette session de création a expiré. Relance `/profil creer`.',
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  clearTimeout(pending.timeout);
  PENDING_CREATIONS.delete(profileKey(interaction));

  const previous = pending.existingProfile || {};
  const profile = {
    ...previous,
    ...pending.global,
    guildId: interaction.guildId,
    userId: interaction.user.id,
    traits: parseEntries(textValue(interaction, 'traits')),
    flaws: parseEntries(textValue(interaction, 'flaws')),
    stats: previous.stats || { ...DEFAULT_STATS },
    createdAt: previous.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  await saveProfile(interaction.guildId, interaction.user.id, profile);
  await interaction.editReply({
    content: mode === 'create'
      ? '✅ Ton profil a été créé ! Tu peux maintenant ajouter ton image avec `/profil image`.'
      : '✅ Ton profil a été modifié.',
    ...(await buildProfileResponse(profile, interaction.user, 'global')),
    components: [createNavigation(interaction.user.id, interaction.guildId, 'global')],
  });
}

async function handleResetButton(interaction) {
  const key = profileKey(interaction);
  const pending = PENDING_RESETS.get(key);
  if (!pending) {
    await interaction.update({
      content: 'Cette demande de réinitialisation a expiré. Relance `/profil reset`.',
      components: [],
      embeds: [],
    });
    return;
  }

  clearTimeout(pending.timeout);
  PENDING_RESETS.delete(key);

  if (interaction.customId.endsWith(':cancel')) {
    await interaction.update({ content: 'Réinitialisation annulée.', components: [], embeds: [] });
    return;
  }

  if (pending.type === 'profil') {
    await deleteProfile(interaction.guildId, pending.targetUserId);
    await interaction.update({
      content: `🗑️ Le profil de <@${pending.targetUserId}> a été supprimé.`,
      components: [],
      embeds: [],
    });
    return;
  }

  const profile = await getProfile(interaction.guildId, pending.targetUserId);
  if (!profile) {
    await interaction.update({ content: 'Ce profil n’existe plus.', components: [], embeds: [] });
    return;
  }

  if (pending.type === 'stats') {
    profile.stats = { ...DEFAULT_STATS };
    profile.statPoints = 0;
    profile.updatedAt = new Date().toISOString();
    await saveProfile(interaction.guildId, pending.targetUserId, profile);

    const targetUser = await interaction.client.users.fetch(pending.targetUserId);
    await interaction.deferUpdate();
    await interaction.editReply({
      content: `✅ Les **statistiques** de <@${pending.targetUserId}> ont été réinitialisées.`,
      ...(await buildProfileResponse(profile, targetUser, 'stats')),
      components: [createNavigation(pending.targetUserId, interaction.guildId, 'stats')],
    });
    return;
  }

  if (pending.type === 'competences') {
    profile.unlockedSkills = [];
    profile.experience = 0;
    profile.updatedAt = new Date().toISOString();
    await saveProfile(interaction.guildId, pending.targetUserId, profile);
    await interaction.update({
      content: `✅ Les **compétences** de <@${pending.targetUserId}> ont été réinitialisées (XP remise à 0).`,
      components: [],
      embeds: [],
    });
  }
}

async function handleButton(interaction) {
  if (interaction.customId.startsWith('profil:reset:')) {
    await handleResetButton(interaction);
    return;
  }

  if (interaction.customId.startsWith('profil:continue:traits:')) {
    const [, , , mode] = interaction.customId.split(':');
    const pending = PENDING_CREATIONS.get(profileKey(interaction));

    if (!pending || pending.mode !== mode) {
      await interaction.reply({
        content: 'Cette session de création a expiré. Relance `/profil creer`.',
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    await interaction.showModal(createTraitsModal(mode, pending.existingProfile || {}));
    return;
  }

  const [, action, page, guildId, targetUserId] = interaction.customId.split(':');
  if (action !== 'page' || guildId !== interaction.guildId) return;

  const profile = await getProfile(guildId, targetUserId);
  if (!profile) {
    await interaction.update({ content: 'Ce profil n’existe plus.', embeds: [], components: [] });
    return;
  }

  const targetUser = await interaction.client.users.fetch(targetUserId);
  await interaction.deferUpdate();
  await interaction.editReply({
    content: undefined,
    ...(await buildProfileResponse(profile, targetUser, page)),
    components: [createNavigation(targetUserId, guildId, page)],
  });
}

async function handleInteraction(interaction) {
  if (interaction.isButton()) {
    if (interaction.customId.startsWith('profil:page:')
      || interaction.customId.startsWith('profil:continue:traits:')
      || interaction.customId.startsWith('profil:reset:')) {
      await handleButton(interaction);
    }
    return;
  }

  if (!interaction.isModalSubmit() || !interaction.customId.startsWith('profil:')) return;
  const [, mode, step] = interaction.customId.split(':');
  if (step === 'global' && ['create', 'edit'].includes(mode)) {
    await handleGlobalModal(interaction, mode);
  } else if (step === 'traits' && ['create', 'edit'].includes(mode)) {
    await handleTraitsModal(interaction, mode);
  }
}

module.exports = {
  data,
  execute,
  handleInteraction,
};
