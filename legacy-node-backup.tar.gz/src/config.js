const path = require('node:path');
require('dotenv').config();

function requiredEnv(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`La variable d'environnement ${name} est manquante.`);
  }
  return value;
}

module.exports = {
  token: requiredEnv('DISCORD_TOKEN'),
  clientId: requiredEnv('CLIENT_ID'),
  guildId: process.env.GUILD_ID || null,
  bannerUrl: process.env.BANNER_URL || null,
  profileBannerUrl: process.env.PROFILE_BANNER_URL || null,
  helpGifUrl: process.env.HELP_GIF_URL || null,
  dataFile: path.join(process.cwd(), 'data', 'profiles.json'),
};
