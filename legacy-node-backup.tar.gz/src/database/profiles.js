const fs = require('node:fs/promises');
const path = require('node:path');
const config = require('../config');
const { DEFAULT_STATS } = require('../data/stats');

const DEFAULT_DATABASE = { profiles: {} };

function normalizeStats(stats = {}) {
  return {
    ...DEFAULT_STATS,
    ...Object.fromEntries(Object.entries(stats)
      .filter(([key, value]) => Object.hasOwn(DEFAULT_STATS, key) && Number.isFinite(value))
      .map(([key, value]) => [key, Math.max(0, Math.floor(value))])),
  };
}

function normalizeProfile(profile) {
  const legacyStats = profile.stats || {};
  const hasNewStats = Object.keys(DEFAULT_STATS).some((statId) => Object.hasOwn(legacyStats, statId));

  return {
    ...profile,
    name: typeof profile.name === 'string' && profile.name.trim() ? profile.name : 'Personnage sans nom',
    race: typeof profile.race === 'string' && profile.race.trim() ? profile.race : 'Race inconnue',
    characterClass: typeof profile.characterClass === 'string' && profile.characterClass.trim()
      ? profile.characterClass
      : 'Classe non définie',
    camp: typeof profile.camp === 'string' && profile.camp.trim() ? profile.camp : 'Camp non défini',
    quote: typeof profile.quote === 'string' ? profile.quote : '',
    traits: Array.isArray(profile.traits) ? profile.traits : [],
    flaws: Array.isArray(profile.flaws) ? profile.flaws : [],
    stats: hasNewStats ? normalizeStats(legacyStats) : { ...DEFAULT_STATS },
    statPoints: Number.isFinite(profile.statPoints) ? Math.max(0, Math.floor(profile.statPoints)) : 0,
    experience: Number.isFinite(profile.experience) ? Math.max(0, Math.floor(profile.experience)) : 0,
    unlockedSkills: Array.isArray(profile.unlockedSkills) ? profile.unlockedSkills : [],
  };
}

async function ensureDatabase() {
  await fs.mkdir(path.dirname(config.dataFile), { recursive: true });

  try {
    await fs.access(config.dataFile);
  } catch {
    await writeDatabase(DEFAULT_DATABASE);
  }
}

async function readDatabase() {
  await ensureDatabase();

  try {
    const content = await fs.readFile(config.dataFile, 'utf8');
    const database = JSON.parse(content);
    return database && database.profiles ? database : DEFAULT_DATABASE;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Le fichier data/profiles.json contient du JSON invalide.');
    }
    throw error;
  }
}

async function writeDatabase(database) {
  const temporaryFile = `${config.dataFile}.tmp`;
  await fs.writeFile(temporaryFile, `${JSON.stringify(database, null, 2)}\n`, 'utf8');
  await fs.rename(temporaryFile, config.dataFile);
}

function profileKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

async function getProfile(guildId, userId) {
  const database = await readDatabase();
  const profile = database.profiles[profileKey(guildId, userId)];
  return profile ? normalizeProfile(profile) : null;
}

async function saveProfile(guildId, userId, profile) {
  const database = await readDatabase();
  const normalizedProfile = normalizeProfile(profile);
  database.profiles[profileKey(guildId, userId)] = normalizedProfile;
  await writeDatabase(database);
  return normalizedProfile;
}

async function deleteProfile(guildId, userId) {
  const database = await readDatabase();
  delete database.profiles[profileKey(guildId, userId)];
  await writeDatabase(database);
}

module.exports = {
  deleteProfile,
  getProfile,
  saveProfile,
};
