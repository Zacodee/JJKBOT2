const { EmbedBuilder } = require('discord.js');
const config = require('./config');

// Palette « Noblesse Jujogo » : bordeaux profond, or travaillé et ivoire.
const BRAND_COLOR = 0x9a0a16;
const GOLD_COLOR = 0xc9b458;
const ANTIQUE_GOLD_COLOR = 0x8a6b2f;
const IVORY_COLOR = 0xf0ece2;
const CHARCOAL_COLOR = 0x252a2e;
const MUTED_BURGUNDY_COLOR = 0x4b0d14;

// Emojis associés à chaque contexte, pour conserver une hiérarchie visuelle cohérente.
const CONTEXT_EMOJIS = {
  profil: '📛',
  stats: '⚔️',
  inventaire: '🎒',
  competences: '🌳',
  panier: '🛒',
};

// Bannière décorative commune (haut de chaque embed), si configurée.
function createBannerEmbed() {
  if (!config.bannerUrl) return null;
  return new EmbedBuilder()
    .setColor(BRAND_COLOR)
    .setImage(config.bannerUrl);
}

// Bannière secondaire réservée aux fiches de profil.
function createProfileBannerEmbed() {
  if (!config.profileBannerUrl) return null;
  return new EmbedBuilder()
    .setColor(ANTIQUE_GOLD_COLOR)
    .setImage(config.profileBannerUrl);
}

// Titre de section inspiré d’un cartouche doré de fiche noble.
function sectionTitle(emoji, text) {
  return `✦ ${emoji} — __${text}__ ✦`;
}

// Ligne de contenu : hiérarchie ivoire/or simulée par Markdown et caractères décoratifs.
function contentLine(emoji, label, value) {
  return `╰─ ${emoji} **${label}** › ⟦ ${value} ⟧`;
}

// Ligne d’information importante, traitée comme un encart de fiche.
function highlightLine(text) {
  return `▌ ✦ ${text}`;
}

// Séparateur décoratif léger, compatible avec les descriptions Discord.
function separator() {
  return '┄ ┄ ┄ ┄ ✦ ┄ ┄ ┄ ┄';
}

// Construit la liste d’embeds d’une réponse : bannière + contenu.
function buildEmbeds(contentEmbed) {
  const bannerEmbed = createBannerEmbed();
  return bannerEmbed ? [bannerEmbed, contentEmbed] : [contentEmbed];
}

module.exports = {
  ANTIQUE_GOLD_COLOR,
  BRAND_COLOR,
  CHARCOAL_COLOR,
  CONTEXT_EMOJIS,
  GOLD_COLOR,
  IVORY_COLOR,
  MUTED_BURGUNDY_COLOR,
  buildEmbeds,
  contentLine,
  createBannerEmbed,
  createProfileBannerEmbed,
  highlightLine,
  sectionTitle,
  separator,
};
