const { REST, Routes } = require('discord.js');
const config = require('./config');
const profilCommand = require('./commands/profil');
const competencesCommand = require('./commands/competences');
const jjkCommand = require('./commands/jjk');

const rest = new REST({ version: '10' }).setToken(config.token);

async function deploy() {
  const route = config.guildId
    ? Routes.applicationGuildCommands(config.clientId, config.guildId)
    : Routes.applicationCommands(config.clientId);

  await rest.put(route, {
    body: [profilCommand.data.toJSON(), competencesCommand.data.toJSON(), jjkCommand.data.toJSON()],
  });
  console.log(config.guildId
    ? 'Commandes enregistrées sur le serveur de test.'
    : 'Commandes enregistrées globalement.');
}

deploy().catch((error) => {
  console.error('Impossible d’enregistrer les commandes slash :', error);
  process.exitCode = 1;
});
