const STAT_DEFINITIONS = [
  { id: 'force', label: 'Force', icon: '⚔️' },
  { id: 'resistance', label: 'Résistance', icon: '🛡️' },
  { id: 'vitesse', label: 'Vitesse', icon: '💨' },
  { id: 'reserveEO', label: "Réserve d'EO", icon: '🔮' },
  { id: 'sortieEO', label: "Sortie d'EO", icon: '🌀' },
];

const DEFAULT_STATS = Object.fromEntries(STAT_DEFINITIONS.map((stat) => [stat.id, 0]));

function getStatDefinition(statId) {
  return STAT_DEFINITIONS.find((stat) => stat.id === statId) || null;
}

module.exports = {
  DEFAULT_STATS,
  STAT_DEFINITIONS,
  getStatDefinition,
};
