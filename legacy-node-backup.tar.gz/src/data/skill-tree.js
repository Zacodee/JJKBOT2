const SKILL_TREE = [
  // Énergie occulte et renforcement
  {
    id: 'manipulation_occult_1', label: 'Manipulation occulte I', branch: 'Énergie occulte', cost: 0, prerequisites: [],
  },
  {
    id: 'manipulation_occult_2', label: 'Manipulation occulte II', branch: 'Énergie occulte', cost: 20, prerequisites: ['manipulation_occult_1'],
  },
  {
    id: 'manipulation_occult_3', label: 'Manipulation occulte III', branch: 'Énergie occulte', cost: 35, prerequisites: ['manipulation_occult_2'],
  },
  {
    id: 'manipulation_occult_4', label: 'Manipulation occulte IV', branch: 'Énergie occulte', cost: 50, prerequisites: ['manipulation_occult_3'],
  },
  {
    id: 'manipulation_occult_5', label: 'Manipulation occulte V', branch: 'Énergie occulte', cost: 100, prerequisites: ['manipulation_occult_4'],
  },
  {
    id: 'reinforcement_1', label: 'Renforcement I', branch: 'Énergie occulte', cost: 10, prerequisites: ['manipulation_occult_1'],
  },
  {
    id: 'reinforcement_2', label: 'Renforcement II', branch: 'Énergie occulte', cost: 20, prerequisites: ['reinforcement_1'],
  },
  {
    id: 'reinforcement_3', label: 'Renforcement III', branch: 'Énergie occulte', cost: 40, prerequisites: ['reinforcement_2'],
  },
  {
    id: 'reinforcement_4', label: 'Renforcement IV', branch: 'Énergie occulte', cost: 50, prerequisites: ['reinforcement_3', 'manipulation_occult_2'],
  },
  {
    id: 'reinforcement_5', label: 'Renforcement V', branch: 'Énergie occulte', cost: 50, prerequisites: ['reinforcement_4', 'manipulation_occult_3'],
  },

  // Stats physiques
  {
    id: 'strength_1', label: 'Force I', branch: 'Stats physiques', cost: 0, prerequisites: [],
  },
  {
    id: 'strength_2', label: 'Force II', branch: 'Stats physiques', cost: 35, prerequisites: ['strength_1'],
  },
  {
    id: 'strength_3', label: 'Force III', branch: 'Stats physiques', cost: 35, prerequisites: ['strength_2'],
  },
  {
    id: 'strength_4', label: 'Force IV', branch: 'Stats physiques', cost: 100, prerequisites: ['strength_3'],
  },
  {
    id: 'speed_1', label: 'Vitesse I', branch: 'Stats physiques', cost: 0, prerequisites: [],
  },
  {
    id: 'speed_2', label: 'Vitesse II', branch: 'Stats physiques', cost: 35, prerequisites: ['speed_1'],
  },
  {
    id: 'speed_3', label: 'Vitesse III', branch: 'Stats physiques', cost: 35, prerequisites: ['speed_2'],
  },
  {
    id: 'speed_4', label: 'Vitesse IV', branch: 'Stats physiques', cost: 100, prerequisites: ['speed_3'],
  },
  {
    id: 'resistance_1', label: 'Résistance I', branch: 'Stats physiques', cost: 0, prerequisites: [],
  },
  {
    id: 'resistance_2', label: 'Résistance II', branch: 'Stats physiques', cost: 35, prerequisites: ['resistance_1'],
  },
  {
    id: 'resistance_3', label: 'Résistance III', branch: 'Stats physiques', cost: 35, prerequisites: ['resistance_2'],
  },
  {
    id: 'resistance_4', label: 'Résistance IV', branch: 'Stats physiques', cost: 100, prerequisites: ['resistance_3'],
  },
  {
    id: 'heavenly_restriction', label: 'Restriction céleste', branch: 'Stats physiques', cost: 0, prerequisites: [],
  },

  // Sorts et extensions
  {
    id: 'basic_extension_1', label: 'Extension de sort basique I', branch: 'Sort', cost: 20, prerequisites: [],
  },
  {
    id: 'basic_extension_2', label: 'Extension de sort basique II', branch: 'Sort', cost: 20, prerequisites: ['basic_extension_1'],
  },
  {
    id: 'basic_extension_3', label: 'Extension de sort basique III', branch: 'Sort', cost: 20, prerequisites: ['basic_extension_2'],
  },
  {
    id: 'basic_extension_4', label: 'Extension de sort basique IV', branch: 'Sort', cost: 25, prerequisites: ['basic_extension_3', 'manipulation_occult_2'],
  },
  {
    id: 'basic_extension_5', label: 'Extension de sort basique V', branch: 'Sort', cost: 30, prerequisites: ['basic_extension_4'],
  },
  {
    id: 'expert_extension_1', label: 'Extension de sort experte I', branch: 'Sort', cost: 35, prerequisites: ['basic_extension_5'],
  },
  {
    id: 'expert_extension_2', label: 'Extension de sort experte II', branch: 'Sort', cost: 35, prerequisites: ['expert_extension_1'],
  },
  {
    id: 'expert_extension_3', label: 'Extension de sort experte III', branch: 'Sort', cost: 35, prerequisites: ['expert_extension_2'],
  },
  {
    id: 'maximum_technique', label: 'Sort maximum', branch: 'Sort', cost: 75, prerequisites: ['expert_extension_3', 'manipulation_occult_5'],
  },

  // Sort d’inversion / RCT
  {
    id: 'rct_1', label: 'Sort d’inversion I', branch: 'Sort d’inversion (RCT)', cost: 45, prerequisites: [],
  },
  {
    id: 'rct_2', label: 'Sort d’inversion II', branch: 'Sort d’inversion (RCT)', cost: 55, prerequisites: ['rct_1'],
  },
  {
    id: 'rct_3', label: 'Sort d’inversion III', branch: 'Sort d’inversion (RCT)', cost: 70, prerequisites: ['rct_2'],
  },
  {
    id: 'rct_4', label: 'Sort d’inversion IV', branch: 'Sort d’inversion (RCT)', cost: 70, prerequisites: ['rct_3'],
  },
  {
    id: 'rct_5', label: 'Sort d’inversion absolue', branch: 'Sort d’inversion (RCT)', cost: 100, prerequisites: ['rct_4'],
  },
  {
    id: 'reverse_extension', label: 'Extension de sort inversée', branch: 'Sort d’inversion (RCT)', cost: 50, prerequisites: ['rct_3'],
  },

  // Barrières et domaines
  {
    id: 'barrier_1', label: 'Barrière I — Rideaux', branch: 'Techniques de barrière', cost: 10, prerequisites: [],
  },
  {
    id: 'barrier_2', label: 'Barrière II', branch: 'Techniques de barrière', cost: 20, prerequisites: ['barrier_1'],
  },
  {
    id: 'barrier_3', label: 'Barrière III', branch: 'Techniques de barrière', cost: 35, prerequisites: ['barrier_2', 'manipulation_occult_3'],
  },
  {
    id: 'barrier_4', label: 'Barrière IV', branch: 'Techniques de barrière', cost: 60, prerequisites: ['barrier_3'],
  },
  {
    id: 'barrier_5', label: 'Barrière V', branch: 'Techniques de barrière', cost: 80, prerequisites: ['barrier_4'],
  },
  {
    id: 'simple_domain_1', label: 'Territoire simple I', branch: 'Domaines', cost: 20, prerequisites: ['barrier_3'],
  },
  {
    id: 'simple_domain_2', label: 'Territoire simple II', branch: 'Domaines', cost: 20, prerequisites: ['simple_domain_1'],
  },
  {
    id: 'simple_domain_3', label: 'Territoire simple III', branch: 'Domaines', cost: 50, prerequisites: ['simple_domain_2'],
  },
  {
    id: 'anti_domain', label: 'Mesures anti-domaines', branch: 'Domaines', cost: 0, prerequisites: ['simple_domain_2'],
  },
  {
    id: 'petal_rain', label: 'Pluie de pétales épris', branch: 'Domaines', cost: 50, prerequisites: ['anti_domain'],
  },
  {
    id: 'void_basket', label: 'Arcane — Panier du vide', branch: 'Domaines', cost: 50, prerequisites: ['anti_domain'],
  },
  {
    id: 'domain_extension_1', label: 'Extension du territoire I', branch: 'Domaines', cost: 75, prerequisites: ['barrier_3'],
  },
  {
    id: 'domain_extension_2', label: 'Extension du territoire II', branch: 'Domaines', cost: 100, prerequisites: ['domain_extension_1', 'barrier_4'],
  },
  {
    id: 'domain_extension_3', label: 'Extension du territoire III', branch: 'Domaines', cost: 50, prerequisites: ['domain_extension_2', 'barrier_5'],
  },
  {
    id: 'territory_prolongation', label: 'Prolongement du territoire', branch: 'Domaines', cost: 100, prerequisites: ['barrier_4'],
  },
  {
    id: 'open_domain', label: 'Territoire ouvert', branch: 'Domaines', cost: 150, prerequisites: ['barrier_5', 'manipulation_occult_5'],
  },
];

const SKILLS_BY_ID = new Map(SKILL_TREE.map((skill) => [skill.id, skill]));

function getSkill(skillId) {
  return SKILLS_BY_ID.get(skillId) || null;
}

function getMissingPrerequisites(skillId, unlockedSkills = []) {
  const skill = getSkill(skillId);
  if (!skill) return [];
  const unlocked = new Set(unlockedSkills);
  return skill.prerequisites
    .map((prerequisiteId) => getSkill(prerequisiteId))
    .filter((prerequisite) => prerequisite && !unlocked.has(prerequisite.id));
}

function canUnlockSkill(profile, skill) {
  if (!skill || profile.unlockedSkills.includes(skill.id)) return false;
  return profile.experience >= skill.cost
    && getMissingPrerequisites(skill.id, profile.unlockedSkills).length === 0;
}

module.exports = {
  SKILL_TREE,
  canUnlockSkill,
  getMissingPrerequisites,
  getSkill,
};
